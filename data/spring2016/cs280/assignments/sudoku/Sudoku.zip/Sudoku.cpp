/******************************************************************************/
/*!
\file   Sudoku.cpp
\author Damien Baca
\par    email: damien.baca@digipen.edu
\par    DigiPen login: damien.baca
\par    Course: CS280
\par    Assignment #3
\date   2/17/2016
\brief  
  This is the implementation file for all member functions
  of a class called Sudoku, as specified in specification
  file Sudoku.h.  

*/
/******************************************************************************/
#include "Sudoku.h"

#define MAX_DUPLICATES 3

/******************************************************************************/
/*!

  Initializes everything needed
          
  \param basesize
    basesize of each neighborhood. Ex. for 9x9 grid, it would be 3

  \param stype
    Are we using letters or numbers

  \param callback
    Returns info to the calling function

*/
/******************************************************************************/
Sudoku::Sudoku(int basesize, SymbolType stype, SUDOKU_CALLBACK callback) {
 	board_         = new char[(basesize * basesize) * (basesize * basesize)];
 	stats_         = new SudokuStats;
 	duplicates_    = new int[MAX_DUPLICATES];

 	// No duplicates at start
  	for(int i = 0; i < MAX_DUPLICATES; ++i)
  		duplicates_[i] = -1;

  	type_ = stype;
  	exit_ = false;
  	stats_->basesize = basesize;
  	Callback_ = callback;
}

/******************************************************************************/
/*!

  Cleans up the meory

*/
/******************************************************************************/
Sudoku::~Sudoku() {
  delete [](board_);
  delete(stats_);
  delete [](duplicates_);
}

/******************************************************************************/
/*!

  Returns the board

*/
/******************************************************************************/
const char *Sudoku::GetBoard() const {
  return board_;
}

/******************************************************************************/
/*!

  Returns the stats

*/
/******************************************************************************/
Sudoku::SudokuStats Sudoku::GetStats() const {
  return *stats_;
}

/******************************************************************************/
/*!

  Writes in any values known before hand

  /param values
  	Known values

  /param size
  	size of the grid

*/
/******************************************************************************/
void Sudoku::SetupBoard(const char *values, int size) {
	for(int i = 0; i < size; ++i) {
		if(values[i] == '.') {
			board_[i] = EMPTY_CHAR;
		} else {
			board_[i] = values[i];
		}
	}
}


/******************************************************************************/
/*!

  Solves the sudoku board

*/
/******************************************************************************/
void Sudoku::Solve() {
	int gridsize = (stats_->basesize * stats_->basesize);
	int last_index = (gridsize * gridsize) - 1;

	// Callback //
	char start;
    if(type_ == SYM_LETTER)
    	start = 'A';
    if(type_ == SYM_NUMBER)
    	start = '1';
	Callback_(*this, board_, MSG_STARTING, 0, stats_->basesize, 0, start, duplicates_);
    //////////////

    stats_->moves++;

	bool result = place_value(0);

    stats_->moves--;

	if(result == true) {
		Callback_(*this, board_, MSG_FINISHED_OK, stats_->moves, stats_->basesize, last_index, board_[last_index], duplicates_);
	} else {
		Callback_(*this, board_, MSG_FINISHED_FAIL, stats_->moves, stats_->basesize, last_index, board_[last_index], duplicates_);
	}
	return;
}

/******************************************************************************/
/*!

  Place values recursively to solve the board

  /param index
  	Where to place the value
  
*/
/******************************************************************************/
bool Sudoku::place_value(int index) {
	int gridsize = (stats_->basesize * stats_->basesize);
	int last_index = (gridsize * gridsize) - 1;
	bool conflict;
	char start;
	char temp;
	bool ret;
    
	while(board_[index] != EMPTY_CHAR) {
		if(index == last_index)
			return true;
		index++;
	}

	if( Callback_(*this, board_, MSG_ABORT_CHECK, stats_->moves, stats_->basesize, index, board_[index], duplicates_) == true ) {
		exit_ = true;
		return false;
	}
    
    stats_->placed++;
	if(type_ == SYM_LETTER)
		start = 'A';
	if(type_ == SYM_NUMBER)
		start = '1';

    char lastval = (char)(start + gridsize - 1);
	board_[index] = start;
	conflict = Conflict(index);
	Callback_(*this, board_, MSG_PLACING, stats_->moves, stats_->basesize, index, board_[index], duplicates_);
    
	while(board_[index] < lastval) {
		if(conflict == false) {
			stats_->moves++;
			
			if(index == last_index)
				return true;

			ret = place_value(index + 1);
			if(exit_ == true)
				return false;
			if(ret == true)
				return true;
		}

		temp = board_[index];
		board_[index] = EMPTY_CHAR;
    	stats_->placed--;
		Callback_(*this, board_, MSG_REMOVING, stats_->moves, stats_->basesize, index, temp, duplicates_);
    	stats_->placed++;
		board_[index] = temp;
		board_[index]++;

    	
		stats_->moves++;
		conflict = Conflict(index);
		Callback_(*this, board_, MSG_PLACING, stats_->moves, stats_->basesize, index, board_[index], duplicates_);
	}
	if(board_[index] == lastval) {
		if(conflict == false) {
			if(index == last_index) {
				return true;
			}
			stats_->moves++;
			ret = place_value(index + 1);
			if(exit_ == true)
				return false;
			if(ret == true)
				return true;

		}		
		stats_->placed--;
		temp = board_[index];
		board_[index] = EMPTY_CHAR;
		Callback_(*this, board_, MSG_REMOVING, stats_->moves, stats_->basesize, index, temp, duplicates_);
		stats_->backtracks++;
		return false;
	}
	return true;
}

/******************************************************************************/
/*!

  Is there a conflict?

  /param index
  	Location being checked
  
*/
/******************************************************************************/
bool Sudoku::Conflict(int index) {
	int gridsize = (stats_->basesize * stats_->basesize);
	int last_index = (gridsize * gridsize) - 1;
	int check_index = index;
	int right_values = index % gridsize;;
	int left_values = gridsize - ((index % gridsize) + 1); 

	int conf1 = -1;
    int conf2 = -1;
    int conf3 = -1;

	bool conflict = false;

    
	///////////////////////////////////////////////////////////////////////
	// Check Up && Down ///////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////

	// Up
	while(check_index - gridsize >= 0) {
		check_index = check_index - gridsize;
		if(board_[check_index] == board_[index]) {
			conf1 = check_index;
			conflict = true;
		}
	}
	check_index = index;

	// Down
	while(check_index + gridsize <= last_index) {
		check_index = check_index + gridsize;
		if(board_[check_index] == board_[index]) {
			conf1 = check_index;
			conflict = true;
		}
	}
	check_index = index;
    
	///////////////////////////////////////////////////////////////////////
	// Check Right && Left ////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////
	//std::cout << "CONF2_BEFORE = "<< conf2 << std::endl;

	// Check Left 
	for(int i = 1; i <= right_values; ++i) {	
		if(board_[index - i] == board_[index]) {
			conf2 = index - i;
			conflict = true;
			break;
		}
	}
	//std::cout << "CONF2_LEFT = "<< conf2 << std::endl;

	// Check Right
	for(int i = 1; i <= left_values; ++i) {
		if(board_[index + i] == board_[index]) {
			conf2 = index + i;
			conflict = true;
			break;

		}
	}
	//std::cout << "CONF2_RIGHT = "<< conf2 << std::endl;

	///////////////////////////////////////////////////////////////////////
	// Check Neighborhood /////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////

    int section_size  = gridsize * stats_->basesize;
    check_index = index;

	//////////////////////////////////////////////////////////////////////////////////////////
	// Check Neighborhood Above //////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////
	while(!(check_index % section_size < gridsize && check_index % stats_->basesize == 0)) {
		if(board_[check_index] == board_[index] && index != check_index) {
			conf3 = check_index;				
			conflict = true;
			break;
		}
		if(check_index % stats_->basesize == 0)
			check_index -= ((stats_->basesize - 1) * stats_->basesize) + 1;
		else
			check_index--;
	}
	if(board_[check_index] == board_[index] && index != check_index) {
		conf3 = check_index;			
		conflict = true;
	}

	//////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////

    check_index = index;

	while(!(check_index % stats_->basesize == (stats_->basesize - 1) && check_index % section_size > (stats_->basesize - 1) * gridsize)) {
		if(board_[check_index] == board_[index] && index != check_index) {
			conf3 = check_index;
			conflict = true;
			break;
		}
		if(check_index % stats_->basesize == (stats_->basesize - 1))
			check_index += ((stats_->basesize - 1) * stats_->basesize) + 1;
		else
			check_index++;
	}
	if(board_[check_index] == board_[index] && index != check_index) {
		conf3 = check_index;
		conflict = true;
	}


	// No duplicates at start
    for(int i = 0; i < MAX_DUPLICATES; ++i)
    	duplicates_[i] = 9999;

    if(conf1 == conf2  && conf1 == conf3) {
    	conf3 = -1;
    	conf2 = -1;
    }

    if(conf1 == conf3)
    	conf3 = -1;
    if(conf1 == conf2)
    	conf2 = -1;
    if(conf2 == conf3)
    	conf3 = -1;

    Insert_Conflict(conf1);
    Insert_Conflict(conf2);
    Insert_Conflict(conf3);

    for(int i = 0; i < MAX_DUPLICATES; ++i) {
    	if(duplicates_[i] == 9999)
    		duplicates_[i] = -1;
    }


	if(conflict == true)
		return true;

	return false;
}

/******************************************************************************/
/*!

  Inserts elements in a sorted manner

  /param element being inserted
  
*/
/******************************************************************************/
void Sudoku::Insert_Conflict(int index) {
	int i = 2;  
  	while ((i > 0) && (index < duplicates_[i - 1])) {   
     	 duplicates_[i] = duplicates_[i - 1];
     	 i--;
    }
 	 duplicates_[i] = index; 
}
