#include <stdio.h>  /* printf             */
#include <stdlib.h> /* malloc, free, exit */
#include <string.h> /* strncpy            */
#include "slist.h"

static sll_node *make_node(int value, const char *label)
{
  sll_node *node = (sll_node *)malloc(sizeof(sll_node));
  if (!node)
  {
    printf("Can't allocate new node.\n");
    exit(-1);
  }

  node->value = value;
  node->next = NULL;

    /* Be sure not to overwrite memory */
  strncpy(node->label, label, LABEL_SIZE - 1);
  node->label[LABEL_SIZE - 1] = 0;
  
  return node;
}

void sll_dump(const sll_node *list)
{
  printf("==================\n");
  while (list)
  {
    printf("%4i: %s\n", list->value, list->label);
    list = list->next;    
  }
}
