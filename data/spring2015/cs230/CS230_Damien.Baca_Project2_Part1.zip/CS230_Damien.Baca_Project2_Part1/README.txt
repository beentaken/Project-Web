/*---------------------------------------------------------------------------
Project Title      : CS 230: Project 2 Part 1
File Name          : Math2D, Matrix2D, Vector2D
Author             : Damien Paige Baca
Creation Date      : 2/6/2015
Purpose            : Implementing a library of collison and math functions

� Copyright 1996-2011, DigiPen Institute of Technology (USA). All rights reserved.
----------------------------------------------------------------------------*/
