/ *---------------------------------------------------------------------------
Project Title      : CS 230: Project 3 Part 1
File Name          : README.txt
Author             : Damien Baca
Creation Date      : 2/24/15
Purpose            : Functions for platformer collision and map data

� Copyright 1996-2011, DigiPen Institute of Technology (USA). All rights reserved.
----------------------------------------------------------------------------*/
