/ *---------------------------------------------------------------------------
Project Title : CS 230: Project 1 Part 1
File Name : main.c, GameStateManager.c, Input.c, System.c, Level1.c, Level2.c
Author : Damien Paige Baca
Creation Date : 1/20/2015
Purpose : Game STate Manager
© Copyright 1996-2011, DigiPen Institute of Technology (USA). All rights reserved.
----------------------------------------------------------------------------*/