enum States { Level_1, Level_2, Restart, Quit};
