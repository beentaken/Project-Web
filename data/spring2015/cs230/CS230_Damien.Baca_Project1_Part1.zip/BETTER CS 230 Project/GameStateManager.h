void GSM_Initialize(int Initial);
void GSM_Update(void);